package WOPackage;

import java.util.ArrayList;


public class WorkoutLog {
    private static String[] options;
    private ArrayList<Exercise> backLog;
    private Exercise current;
    private Integer exp;

    public WorkoutLog(String[] options){
        this.options = options;
        this.exp = 0;
        this.backLog = new ArrayList<Exercise>();
    }

    public void createExercise (String name){
        this.current = new Exercise(name);
    }

    public void logExercise() {

        for (int i = 0; i < backLog.size(); i++) {

            if (backLog.get(i).getName().equals(current.getName())) {
                calcExp(backLog.get(i), current);
                backLog.remove(i);
                backLog.add(i,current);
            }
            else
                backLog.add(current);

        }
    }

    public void calcExp(Exercise old, Exercise current){

        double weightImprovement = current.getAverageWeight()- old.getAverageWeight();

        Integer repImprovement = current.getAverageReps() - old.getAverageReps();

        Integer improvement = repImprovement + (int)weightImprovement;

        if (improvement > 0)
            exp = improvement * 1000;
        else
            exp = 0;
    }

    public int getExp() {
        return exp;
    }

    public Exercise getCurrent() {
        return current;
    }

    public void setBackLog(ArrayList<Exercise> backLog) {
        this.backLog = backLog;
    }

    public ArrayList<Exercise> getBackLog() {
        return backLog;
    }

    public static void setOptions(String[] options) {
        WorkoutLog.options = options;
    }

}
